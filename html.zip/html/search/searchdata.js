var indexSectionsWithContent =
{
  0: "abcdefgiklmprstuvw~",
  1: "acefgvw",
  2: "g",
  3: "gmw",
  4: "abcdegiklmprstuvw~",
  5: "cgkmp",
  6: "a",
  7: "cdept",
  8: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Classes",
  2: "Espaces de nommage",
  3: "Fichiers",
  4: "Fonctions",
  5: "Variables",
  6: "Énumérations",
  7: "Macros",
  8: "Pages"
};

