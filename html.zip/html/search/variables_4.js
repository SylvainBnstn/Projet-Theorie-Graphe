var searchData=
[
  ['page',['page',['../namespacegrman.html#a85e3b6c74febb61a1fa6e42364bb9067',1,'grman']]],
  ['page_5fcolor',['page_color',['../namespacegrman.html#a1576bfdaffb0e7a44eec352a321e1103',1,'grman']]],
  ['page_5fframe',['page_frame',['../namespacegrman.html#aa467808c0e51eb31432d66fa59133b6a',1,'grman']]]
];
