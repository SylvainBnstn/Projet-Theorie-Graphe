var searchData=
[
  ['_7ewidget',['~Widget',['../classgrman_1_1_widget.html#afe924d0aa582bbfb32f28b9e616fcf47',1,'grman::Widget']]]
];
