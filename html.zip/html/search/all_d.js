var searchData=
[
  ['save_5fgraph',['save_graph',['../class_graph.html#aad7815c1c739981dde5a05b73d027c1a',1,'Graph']]],
  ['set_5fbg_5fcolor',['set_bg_color',['../classgrman_1_1_widget.html#ae8f8fc19b6b0981895c38fdf7df4e4bb',1,'grman::Widget']]],
  ['set_5fno_5fgravity',['set_no_gravity',['../classgrman_1_1_widget.html#a61c632d3a7b2dee577e7a0be63fb16ff',1,'grman::Widget']]],
  ['set_5fvertical',['set_vertical',['../classgrman_1_1_widget_text.html#a03b0b3cbba6184e076fbc7894771e99e',1,'grman::WidgetText']]],
  ['suppress_5fedge',['suppress_edge',['../class_graph.html#a8c41e3705254293585791e31df7ad704',1,'Graph']]],
  ['suppress_5fvertex',['suppress_vertex',['../class_graph.html#ae1872078ccdb0a44f7a177f6afaabb7f',1,'Graph']]]
];
